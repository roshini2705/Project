package com.mobile.onlineshopping.service;

import com.mobile.onlineshopping.model.Cart;

public interface CartService {

    boolean saveCart(Cart cart);

    boolean updateCart(Cart cart);

    Cart findCart();

}
